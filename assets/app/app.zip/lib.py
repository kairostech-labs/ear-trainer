import random
from enum import StrEnum

from loguru import logger
from pydantic import BaseModel

from src.constants import ScaleNames, CONST_DICTATION_LENGTH, CONST_QUESTION_OCTAVE_OFFSET


class Note(BaseModel):
    midi_number: int
    name: str
    octave: int
    frequency: float
    semitone: int


class Consonance(StrEnum):
    consonant = "consonant"
    dissonant = "dissonant"


class ConsonanceSubCategory(StrEnum):
    perfect = "perfect"
    imperfect = "imperfect"
    none = "none"


class Width(StrEnum):
    wide = "wide"
    narrow = "narrow"
    none = "none"


class PerfectStability(StrEnum):
    unstable = "unstable"
    distinct = "distinct"
    same = "same"
    none = "none"


class Brightness(StrEnum):
    dark = "dark"
    bright = "bright"
    none = "none"


class Sharpness(StrEnum):
    sharp = "sharp"
    # or mild?
    blunt = "blunt"
    none = "none"


class IntervalInfo(BaseModel):
    semitones: int = 0
    name: str = ""
    interval_name_asc: str = ""
    solfege_name: str = ""
    consonance: Consonance = Consonance.consonant
    consonance_style: ConsonanceSubCategory = ConsonanceSubCategory.none
    brightness: Brightness = Brightness.none
    width: Width = Width.none
    perfect_stability: PerfectStability = PerfectStability.none
    sharpness: Sharpness = Sharpness.none


class SolfegeNames(StrEnum):
    Do = "Do"
    Ra = "Ra"
    Re = "Re"
    Me = "Me"
    Mi = "Mi"
    Fa = "Fa"
    Fi = "Fi"
    So = "So"
    Le = "Le"
    La = "La"
    Te = "Te"
    Ti = "Ti"
    Do_ = "Do_"


interval_map = {
    0: IntervalInfo(
        semitones=0,
        name=SolfegeNames.Do,
        interval_name_asc="Perfect prime",
        solfege_name=SolfegeNames.Do,
        consonance=Consonance.consonant,
        consonance_style=ConsonanceSubCategory.perfect,
        brightness=Brightness.none,
        width=Width.narrow,
        perfect_stability=PerfectStability.same,
    ),
    1: IntervalInfo(
        semitones=1,
        name=SolfegeNames.Ra,
        interval_name_asc="Minor second",
        solfege_name=SolfegeNames.Ra,
        consonance=Consonance.dissonant,
        consonance_style=ConsonanceSubCategory.none,
        brightness=Brightness.dark,
        width=Width.narrow,
        sharpness=Sharpness.sharp,
    ),
    2: IntervalInfo(
        semitones=2,
        name=SolfegeNames.Re,
        interval_name_asc="Major second",
        solfege_name=SolfegeNames.Re,
        consonance=Consonance.dissonant,
        consonance_style=ConsonanceSubCategory.none,
        brightness=Brightness.bright,
        width=Width.narrow,
        sharpness=Sharpness.blunt,
    ),
    3: IntervalInfo(
        semitones=3,
        name=SolfegeNames.Me,
        interval_name_asc="Minor third",
        solfege_name=SolfegeNames.Me,
        consonance=Consonance.consonant,
        consonance_style=ConsonanceSubCategory.imperfect,
        brightness=Brightness.dark,
        width=Width.narrow,
    ),
    4: IntervalInfo(
        semitones=4,
        name=SolfegeNames.Mi,
        interval_name_asc="Major third",
        solfege_name=SolfegeNames.Mi,
        consonance=Consonance.consonant,
        consonance_style=ConsonanceSubCategory.imperfect,
        brightness=Brightness.bright,
        width=Width.narrow,
    ),
    5: IntervalInfo(
        semitones=5,
        name=SolfegeNames.Fa,
        interval_name_asc="Perfect fourth",
        solfege_name=SolfegeNames.Fa,
        consonance=Consonance.consonant,
        consonance_style=ConsonanceSubCategory.perfect,
        brightness=Brightness.none,
        width=Width.none,
        perfect_stability=PerfectStability.unstable,
    ),
    6: IntervalInfo(
        semitones=6,
        name=SolfegeNames.Fi,
        interval_name_asc="Tritone",
        solfege_name=SolfegeNames.Fi,
        consonance=Consonance.dissonant,
        consonance_style=ConsonanceSubCategory.none,
        brightness=Brightness.none,
        width=Width.none,
    ),
    7: IntervalInfo(
        semitones=7,
        name=SolfegeNames.So,
        interval_name_asc="Perfect fifth",
        solfege_name=SolfegeNames.So,
        consonance=Consonance.consonant,
        consonance_style=ConsonanceSubCategory.perfect,
        brightness=Brightness.none,
        width=Width.none,
        perfect_stability=PerfectStability.distinct,
    ),
    8: IntervalInfo(
        semitones=8,
        name=SolfegeNames.Le,
        interval_name_asc="Minor sixth",
        solfege_name=SolfegeNames.Le,
        consonance=Consonance.consonant,
        consonance_style=ConsonanceSubCategory.imperfect,
        brightness=Brightness.dark,
        width=Width.wide,
    ),
    9: IntervalInfo(
        semitones=9,
        name=SolfegeNames.La,
        interval_name_asc="Major sixth",
        solfege_name=SolfegeNames.La,
        consonance=Consonance.consonant,
        consonance_style=ConsonanceSubCategory.imperfect,
        brightness=Brightness.bright,
        width=Width.wide,
    ),
    10: IntervalInfo(
        semitones=10,
        name=SolfegeNames.Te,
        interval_name_asc="Minor seventh",
        solfege_name=SolfegeNames.Te,
        consonance=Consonance.dissonant,
        consonance_style=ConsonanceSubCategory.none,
        brightness=Brightness.dark,
        width=Width.wide,
        sharpness=Sharpness.blunt,
    ),
    11: IntervalInfo(
        semitones=11,
        name=SolfegeNames.Ti,
        interval_name_asc="Major seventh",
        solfege_name=SolfegeNames.Ti,
        consonance=Consonance.dissonant,
        consonance_style=ConsonanceSubCategory.none,
        brightness=Brightness.bright,
        width=Width.wide,
        sharpness=Sharpness.sharp,
    ),
    12: IntervalInfo(
        semitones=12,
        name=SolfegeNames.Do_,
        interval_name_asc="Octave",
        solfege_name=SolfegeNames.Do_,
        consonance=Consonance.consonant,
        consonance_style=ConsonanceSubCategory.perfect,
        brightness=Brightness.none,
        width=Width.wide,
        perfect_stability=PerfectStability.same,
    ),
}


chromatic_notes: list = [
    "C",
    "C#",
    "D",
    "D#",
    "E",
    "F",
    "F#",
    "G",
    "G#",
    "A",
    "A#",
    "B",
]
tones = ["do", "rey", "mi", "fa", "so", "la", "ti", "do"]


class QuestionTone(BaseModel):
    octave: int
    scale_index: int


class Question:
    root_note: int
    tone: QuestionTone
    # tones: list[int]
    # tones that are not anchored to the same octave as the cadence
    anchorless_tones: list[QuestionTone] = []
    dictation_length: int = CONST_DICTATION_LENGTH
    dictation_target_index: int = 0
    # smart guitar range
    # instrument_first_note = 40
    # instrument_last_note = 80
    # midi keyboard range
    instrument_first_note = 48
    instrument_last_note = 72 - 12

    @staticmethod
    def get_question_midi_number():
        # TODO add code to adjust for a random octave different to the cadence played
        midi_number = ScaleSetup.test_scale[
            Question.anchorless_tones[Question.dictation_target_index].scale_index
        ].midi_number
        midi_number += (
            Question.anchorless_tones[Question.dictation_target_index].octave * 12
        )
        return midi_number

    @staticmethod
    def get_question_midi_numbers():
        # TODO add code to adjust for a random octave different to the cadence played
        return [
            ScaleSetup.test_scale[
                Question.anchorless_tones[dictation_target_index].scale_index
            ].midi_number
            + Question.anchorless_tones[Question.dictation_target_index].octave * 12
            for dictation_target_index in range(Question.dictation_length)
        ]

    @staticmethod
    def solfege_to_midi_number(solfege_name: str):
        # TODO add code to adjust for a random octave different to the cadence played
        scale_index = ScaleSetup.scale_solfege.index(solfege_name)
        return ScaleSetup.test_scale[scale_index].midi_number

    @staticmethod
    def shuffle_tonic(scale_name: ScaleNames):
        Question.root_note = random.randrange(
            Question.instrument_first_note, Question.instrument_last_note
        )
        ScaleSetup.set_scale_root(Question.root_note, scale_name)

    @staticmethod
    def get_dictation_target_solfege():
        scale_index = Question.anchorless_tones[
            Question.dictation_target_index
        ].scale_index
        scale_solfege = ScaleSetup.scale_solfege[scale_index]
        logger.info((scale_index, scale_solfege, ScaleSetup.scale_solfege))
        return scale_solfege

    @staticmethod
    def get_scale_solfege(scale_index: int):
        return ScaleSetup.scale_solfege[scale_index]

    @staticmethod
    def get_random_question_tone():
        random_scale_index = random.randrange(0, len(ScaleSetup.test_scale))
        logger.info(random_scale_index)
        return QuestionTone(
            octave=CONST_QUESTION_OCTAVE_OFFSET, scale_index=random_scale_index
        )

    @staticmethod
    def shuffle_dictation():
        Question.anchorless_tones = [
            Question.get_random_question_tone()
            for x in range(Question.dictation_length)
        ]
        Question.select_dictation_note(0)

    @staticmethod
    def select_dictation_note(index: int):
        """Target one of the notes in the dictation for identification"""
        Question.tone = Question.anchorless_tones[index]
        Question.dictation_target_index = index

    @staticmethod
    def change_dictation_length(length: int):
        Question.dictation_length = length
        # ensure target is within range of new length
        Question.dictation_target_index = min(
            Question.dictation_target_index, Question.dictation_length
        )

    @staticmethod
    def new_question(scale_name: ScaleNames):
        Question.shuffle_tonic(scale_name)
        Question.shuffle_dictation()


class MidiHelper:

    @staticmethod
    def get_progression_chords(progression_scale):
        progression_scale = ScaleSetup.major_scale

        # 0+1, 3, 5 in the major scale
        c_I = [
            progression_scale[0].midi_number,
            progression_scale[2].midi_number,
            progression_scale[4].midi_number,
        ]
        c_IV = [
            progression_scale[3].midi_number,
            progression_scale[5].midi_number,
            progression_scale[7].midi_number,
        ]
        c_V = [
            progression_scale[4].midi_number,
            progression_scale[6].midi_number,
            progression_scale[1].midi_number + 12,
            ]  # V7 chord
        c_vi = [
            progression_scale[5].midi_number,
            progression_scale[7].midi_number,
            progression_scale[2].midi_number + 12,
            ]
        return c_I, c_IV, c_V, c_vi

    @staticmethod
    def get_doo_wop_cadence_notes(test_scale):
        """
        [This chord progression NEVER goes out of style!](https://www.youtube.com/watch?v=s656DS6EMZQ)
        """
        c_I, c_IV, c_V, c_vi = MidiHelper.get_progression_chords(test_scale)
        return [c_I, c_vi, c_IV, c_V]

    @staticmethod
    def get_blues_progression(test_scale):
        """ """
        c_I, c_IV, c_V, c_vi = MidiHelper.get_progression_chords(test_scale)
        return [c_I, c_IV, c_I, c_V, c_IV, c_I]

    @staticmethod
    def get_rock_cadence_notes(test_scale):
        """
        Most of the progressions are resolve strongly to root
        Axis progression delays resolution
        [Evolution of Chord Progressions in pop music and how they work](https://www.youtube.com/watch?v=jr0aAJTtYjI)

        Rock progression simplifies the 12 bar blues
        """
        c_I, c_IV, c_V, c_vi = MidiHelper.get_progression_chords(test_scale)
        return [c_I, c_IV, c_I, c_V, c_I]

    @staticmethod
    def get_training_cadence_notes(test_scale):
        c_I, c_IV, c_V, c_vi = MidiHelper.get_progression_chords(test_scale)
        return [c_I, c_IV, c_V, c_I]

    @staticmethod
    def get_cadence_notes():
        """Returns a list of chords (each chord is a list of MIDI numbers) for cadence."""
        test_scale = ScaleSetup.test_scale
        if not test_scale:
            logger.warning(
                "Scale not set up. Call ScaleSetup.set_major_scale_root first."
            )
            return []

        # return MidiHelper.get_training_cadence_notes(test_scale)
        return MidiHelper.get_doo_wop_cadence_notes(test_scale)

    @staticmethod
    def get_scale_notes(direction="up"):
        """Returns a list of MIDI numbers for the current scale."""
        test_scale = ScaleSetup.test_scale
        if not test_scale:
            logger.warning(
                "Scale not set up. Call ScaleSetup.set_major_scale_root first."
            )
            return []

        if direction == "up":
            return [
                note.midi_number
                for note in ScaleSetup.test_scale[Question.tone.scale_index : 8 : +1]
            ]
        elif direction == "down":
            # in reverse the end step is NOT included
            return [
                note.midi_number
                for note in ScaleSetup.test_scale[Question.tone.scale_index :: -1]
            ]
        else:
            logger.warning("Unexpected direction.")
            return []

    @staticmethod
    def interval() -> tuple[int, int]:
        return (
            ScaleSetup.test_scale[0].midi_number,
            ScaleSetup.test_scale[Question.tone].midi_number,
        )

    @staticmethod
    def midi_number_to_frequency(midi_number: int):
        return 440 * 2 ** ((midi_number - 69) / 12)

class ScaleSetup:
    note_range = range(0, 127)
    chromatic_note_range = [
        Note(
            midi_number=n,
            name=chromatic_notes[n % 12],
            octave=int(n / 12) - 1,
            frequency=MidiHelper.midi_number_to_frequency(n),
            semitone=n % 12,
            )
        for n in note_range
    ]

    scale_solfege = []
    chromatic_scale = []
    upper_major_scale = []
    lower_major_scale = []
    major_scale = []
    natural_minor_scale = []
    training_minor_scale = []
    test_scale: list[Note] = []

    @staticmethod
    def set_scale_root(root_note: int, scale_name: ScaleNames):
        # FIXME the semitone is based on the chromatic_note_range but seems to get scrambled when forming the other scales from chromatic
        # (T-T-S-T-T-T-S)
        ScaleSetup.major_scale = [
            ScaleSetup.chromatic_note_range[root_note + t]
            for t in [0, 2, 4, 5, 7, 9, 11, 12]
        ]
        ScaleSetup.lower_major_scale = ScaleSetup.major_scale[:4]
        ScaleSetup.upper_major_scale = ScaleSetup.major_scale[4:]
        # (W-H-W-W-H-W-W)
        ScaleSetup.natural_minor_scale = [
            ScaleSetup.chromatic_note_range[root_note + t]
            for t in [0, 2, 3, 5, 7, 8, 10, 12]
        ]
        ScaleSetup.training_minor_scale = [
            ScaleSetup.chromatic_note_range[root_note + t]
            for t in [0, 1, 3, 5, 7, 8, 10, 12]
        ]
        ScaleSetup.chromatic_scale = [
            ScaleSetup.chromatic_note_range[root_note + t] for t in range(13)
        ]
        logger.info(ScaleSetup.chromatic_scale)
        ScaleSetup.set_scale(scale_name)

    @staticmethod
    def set_scale(scale_name: ScaleNames):
        if scale_name == ScaleNames.major:
            ScaleSetup.test_scale = ScaleSetup.major_scale
            ScaleSetup.scale_solfege = [
                SolfegeNames.Do,
                SolfegeNames.Re,
                SolfegeNames.Mi,
                SolfegeNames.Fa,
                SolfegeNames.So,
                SolfegeNames.La,
                SolfegeNames.Ti,
                SolfegeNames.Do_,
            ]
        elif scale_name == ScaleNames.upper_major:
            ScaleSetup.test_scale = ScaleSetup.upper_major_scale
            ScaleSetup.scale_solfege = [
                SolfegeNames.So,
                SolfegeNames.La,
                SolfegeNames.Ti,
                SolfegeNames.Do_,
            ]
        elif scale_name == ScaleNames.lower_major:
            ScaleSetup.test_scale = ScaleSetup.lower_major_scale
            ScaleSetup.scale_solfege = [
                SolfegeNames.Do,
                SolfegeNames.Re,
                SolfegeNames.Mi,
                SolfegeNames.Fa,
            ]
        elif scale_name == ScaleNames.training_minor:
            ScaleSetup.test_scale = ScaleSetup.training_minor_scale
            # natural minor scale actually has a major second (Re) instead of (Ra)
            ScaleSetup.scale_solfege = [
                SolfegeNames.Do,
                SolfegeNames.Ra,
                SolfegeNames.Me,
                SolfegeNames.Fa,
                SolfegeNames.So,
                SolfegeNames.Le,
                SolfegeNames.Te,
                SolfegeNames.Do_,
            ]
        elif scale_name == ScaleNames.natural_minor:
            ScaleSetup.test_scale = ScaleSetup.natural_minor_scale
            # natural minor scale actually has a major second (Re) instead of (Ra)
            ScaleSetup.scale_solfege = [
                SolfegeNames.Do,
                SolfegeNames.Re,
                SolfegeNames.Me,
                SolfegeNames.Fa,
                SolfegeNames.So,
                SolfegeNames.Le,
                SolfegeNames.Te,
                SolfegeNames.Do_,
            ]
        else:
            ScaleSetup.test_scale = ScaleSetup.chromatic_scale
            ScaleSetup.scale_solfege = [
                SolfegeNames.Do,
                SolfegeNames.Ra,
                SolfegeNames.Re,
                SolfegeNames.Me,
                SolfegeNames.Mi,
                SolfegeNames.Fa,
                SolfegeNames.Fi,
                SolfegeNames.So,
                SolfegeNames.Le,
                SolfegeNames.La,
                SolfegeNames.Te,
                SolfegeNames.Ti,
                SolfegeNames.Do_,
            ]

