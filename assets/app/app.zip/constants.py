from enum import StrEnum


class ScaleNames(StrEnum):
    major = "major"
    natural_minor = "natural_minor"
    training_minor = "training_minor"
    chromatic = "chromatic"
    upper_major = "upper_major"
    lower_major = "lower_major"


CONST_DEFAULT_SCALE = ScaleNames.major
CONST_DICTATION_LENGTH = 1
# octave -1, 0, 1 for down -1 or up +1 an octave
CONST_QUESTION_OCTAVE_OFFSET = 0
# CONST_SAMPLE_RATE = 44100
CONST_SAMPLE_RATE = 24000
CONST_BRAIN_WORKSHOP_SOUNDS_FOLDER = (
    "/Users/conal/PycharmProjects/brainworkshop/res/sounds"
)
CONST_PIANOSCALE_FOLDER = (
    f"/Users/conal/PycharmProjects/brainworkshop/res/sounds/pianoscale"
)
